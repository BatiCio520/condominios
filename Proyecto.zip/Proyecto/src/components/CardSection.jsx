// filepath: c:\Users\sanch\OneDrive\Escritorio\Proyecto\src\components\CardSection.jsx
import React from "react";
import { Link } from "react-router-dom";
import registroImg from "../IMAGENES/REGISTRO.png";
import gastosImg from "../IMAGENES/GASTOS.png";
import reservaImg from "../IMAGENES/RESERVA.png";
import reportesImg from "../IMAGENES/REPORTES.png";

function CardSection() {
  return (
    <section className="tarjetas">
      <div className="card">
        <Link className="historia" to="/registro">
          <img className="card-img" src={registroImg} alt="Registro" />
          <h6>REGISTRO</h6>
        </Link>
      </div>
      <div className="card">
        <Link to="/gastos">
          <img className="card-img" src={gastosImg} alt="Gastos" />
          <h6>GASTOS</h6>
        </Link>
      </div>
      <div className="card">
        <Link to="/reserva">
          <img className="card-img" src={reservaImg} alt="Reservas" />
          <h6>RESERVAS</h6>
        </Link>
      </div>
      <div className="card">
        <Link to="/reporte">
          <img className="card-img" src={reportesImg} alt="Reportes" />
          <h6>REPORTES</h6>
        </Link>
      </div>
    </section>
  );
}

export default CardSection;