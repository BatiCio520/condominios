import React, { useState } from "react";

const espacios = [
  { nombre: "Estacionamiento", key: "estacionamiento" },
  { nombre: "Quinchos", key: "quinchos" },
  { nombre: "Multicancha", key: "multicancha" },
  { nombre: "Sala de Eventos", key: "sala-eventos" },
];

function Reserva() {
  const [form, setForm] = useState({
    nombre: "",
    fecha: "",
    hora: "",
    reservas: [],
    pagos: {},
  });

  // Datos de ejemplo para la tabla
  const [reservas, setReservas] = useState([
    {
      nombre: "Juan Pérez",
      espacio: "Quinchos",
      fecha: "2025-10-10",
      hora: "18:00",
      costo: 15000,
      estado: "Reservado",
    },
    {
      nombre: "Ana López",
      espacio: "Sala de Eventos",
      fecha: "2025-10-12",
      hora: "20:00",
      costo: 25000,
      estado: "Reservado",
    },
  ]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setForm((prev) => ({
        ...prev,
        reservas: checked
          ? [...prev.reservas, name]
          : prev.reservas.filter((r) => r !== name),
      }));
    } else if (name.startsWith("pago-")) {
      setForm((prev) => ({
        ...prev,
        pagos: { ...prev.pagos, [name]: value },
      }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const isChecked = (key) => form.reservas.includes(key);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.nombre || !form.fecha || !form.hora || form.reservas.length === 0) return;
    form.reservas.forEach((espacio) => {
      setReservas((prev) => [
        ...prev,
        {
          nombre: form.nombre,
          espacio: espacios.find((e) => e.key === espacio).nombre,
          fecha: form.fecha,
          hora: form.hora,
          costo: form.pagos[`pago-${espacio}`] || 0,
          estado: "Reservado",
        },
      ]);
    });
    setForm({
      nombre: "",
      fecha: "",
      hora: "",
      reservas: [],
      pagos: {},
    });
  };

  return (
    <main>
      <h1>Reserva de Espacios</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="nombre">Nombre:</label>
          <input
            type="text"
            id="nombre"
            name="nombre"
            value={form.nombre}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="fecha">Fecha de la Reserva:</label>
          <input
            type="date"
            id="fecha"
            name="fecha"
            value={form.fecha}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="hora">Hora de la Reserva:</label>
          <input
            type="time"
            id="hora"
            name="hora"
            value={form.hora}
            onChange={handleChange}
            required
          />
        </div>
        <h2>Seleccione el tipo de reserva</h2>
        {espacios.map((espacio) => (
          <div key={espacio.key}>
            <label htmlFor={espacio.key}>{`Reserva de ${espacio.nombre}`}</label>
            <input
              type="checkbox"
              id={espacio.key}
              name={espacio.key}
              checked={isChecked(espacio.key)}
              onChange={handleChange}
            />
            {isChecked(espacio.key) && (
              <input
                type="number"
                id={`pago-${espacio.key}`}
                name={`pago-${espacio.key}`}
                placeholder="Monto en $"
                value={form.pagos[`pago-${espacio.key}`] || ""}
                onChange={handleChange}
                required
              />
            )}
          </div>
        ))}
        <button type="submit">Reservar</button>
      </form>

      <h1>Gestión de Reservas</h1>
      <section>
        <h2>Listado de Reservas</h2>
        <table border="1">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Espacio Reservado</th>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Costo</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {reservas.length === 0 ? (
              <tr>
                <td colSpan="6">No hay reservas registradas.</td>
              </tr>
            ) : (
              reservas.map((r, i) => (
                <tr key={i}>
                  <td>{r.nombre}</td>
                  <td>{r.espacio}</td>
                  <td>{r.fecha}</td>
                  <td>{r.hora}</td>
                  <td>${r.costo}</td>
                  <td>{r.estado}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </main>
  );
}

export default Reserva;