import React, { useEffect, useState } from "react";

function Gastos() {
  //Datos de ejemplo
  const [gastos, setGastos] = useState([
    { nombre: "Juan Pérez", depto: "A101", monto: "35000", estado: "Pagado" },
    { nombre: "Ana López", depto: "B202", monto: "42000", estado: "Pendiente" },
    { nombre: "Carlos Ruiz", depto: "C303", monto: "39000", estado: "Pagado" },
  ]);
  const [filtro, setFiltro] = useState("Todos");
  const [form, setForm] = useState({ nombre: "", depto: "", monto: "", estado: "Pagado" });

  const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

  //Cargar gastos desde la API al montar 
  useEffect(() => {
    fetch(`${API}/api/gastos`)
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data) && data.length) setGastos(data.map(g => ({ ...g, monto: String(g.monto) })));
      })
      .catch(() => {/* si falla, se mantienen los datos de ejemplo */});
  }, []);

  //Manejar cambios en el formulario
  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  //Manejar envio del formulario
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${API}/api/gastos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, monto: Number(form.monto) }),
      });
      if (!res.ok) throw new Error("Error al crear");
      const nuevo = await res.json();
      setGastos(prev => [nuevo, ...prev]);
      setForm({ nombre: "", depto: "", monto: "", estado: "Pagado" });
    } catch (err) {
      // fallback: añadir localmente si backend falla
      setGastos(prev => [{ ...form }, ...prev]);
      setForm({ nombre: "", depto: "", monto: "", estado: "Pagado" });
    }
  };

  //Filtrar gastos según el filtro seleccionado
  const gastosFiltrados = gastos.filter(g => filtro === "Todos" ? true : g.estado === filtro);

  //Suma de totales 
  const total = gastosFiltrados.reduce((acc, g) => acc + Number(g.monto || 0), 0);

  return (
    <main>
      <h1>Gestión de Gastos</h1>
      <section>
        <h2>Agregar Gasto</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value={form.nombre} onChange={handleChange} required />
          </div>
          <div>
            <label htmlFor="depto">Departamento:</label>
            <input type="text" id="depto" name="depto" value={form.depto} onChange={handleChange} required />
          </div>
          <div>
            <label htmlFor="monto">Monto:</label>
            <input type="number" id="monto" name="monto" value={form.monto} onChange={handleChange} required />
          </div>
          <div>
            <label htmlFor="estado">Estado:</label>
            <select id="estado" name="estado" value={form.estado} onChange={handleChange} required>
              <option value="Pagado">Pagado</option>
              <option value="Pendiente">Pendiente</option>
            </select>
          </div>
          <button type="submit">Agregar Gasto</button>
        </form>
      </section>

      <section>
        <h2>Listado de Gastos</h2>
        <div>
          <button onClick={() => setFiltro("Todos")}>Mostrar Todos</button>
          <button onClick={() => setFiltro("Pendiente")}>Mostrar Morosos</button>
          <button onClick={() => setFiltro("Pagado")}>Mostrar Pagados</button>
        </div>
      </section>

      <section>
        <table border="1">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Departamento</th>
              <th>Monto</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {gastosFiltrados.length === 0 ? (
              <tr>
                <td colSpan="4">No hay gastos registrados.</td>
              </tr>
            ) : (
              gastosFiltrados.map((g, i) => (
                <tr key={i}>
                  <td>{g.nombre}</td>
                  <td>{g.depto}</td>
                  <td>{g.monto}</td>
                  <td>{g.estado}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
        <p id="totales">Total: ${total}</p>
      </section>
    </main>
  );
}

export default Gastos;