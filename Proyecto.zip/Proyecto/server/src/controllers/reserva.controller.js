import Reserva from "../models/reserva.model.js";

export const listarReservas = async (req, res) => {
  try {
    const reservas = await Reserva.find().sort({ createdAt: -1 });
    res.json(reservas);
  } catch (err) {
    res.status(500).json({ msg: "Error listando reservas", error: err.message });
  }
};

export const crearReserva = async (req, res) => {
  try {
    const { nombre, espacio, fecha, hora, costo } = req.body;
    const r = new Reserva({ nombre, espacio, fecha, hora, costo });
    await r.save();
    res.status(201).json(r);
  } catch (err) {
    res.status(400).json({ msg: "Error creando reserva", error: err.message });
  }
};