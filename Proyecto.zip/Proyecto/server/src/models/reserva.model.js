import mongoose from "mongoose";

const ReservaSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  espacio: { type: String, required: true },
  fecha: { type: String, required: true }, // ISO date string o mantener formato simple
  hora: { type: String, required: true },
  costo: { type: Number, default: 0 },
  estado: { type: String, enum: ["Reservado", "Cancelado", "Finalizado"], default: "Reservado" },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("Reserva", ReservaSchema);