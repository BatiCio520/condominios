import express from "express";
import { listarReservas, crearReserva } from "../controllers/reserva.controller.js";

const router = express.Router();

router.get("/", listarReservas);
router.post("/", crearReserva);

export default router;