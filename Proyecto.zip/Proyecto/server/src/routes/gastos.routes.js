import express from "express";
import { listarGastos, crearGasto, totalGastos } from "../controllers/gastos.controller.js";
import { validarGasto } from "../middlewares/validar.js";

const router = express.Router();

router.get("/", listarGastos);
router.post("/", validarGasto, crearGasto);
router.get("/total", totalGastos);

export default router;