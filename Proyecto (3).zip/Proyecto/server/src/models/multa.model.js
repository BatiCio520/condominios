import mongoose from "mongoose";

const MultaSchema = new mongoose.Schema({
  residenteId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  motivo: { type: String },
  monto: { type: Number, required: true },
  fecha: { type: Date, default: Date.now },
  activo: { type: Boolean, default: true }
});

export default mongoose.model("Multa", MultaSchema);