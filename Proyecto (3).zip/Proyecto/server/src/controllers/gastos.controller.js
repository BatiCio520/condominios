import Gasto from "../models/gasto.model.js";

export const listarGastos = async (req, res) => {
  try {
    const gastos = await Gasto.find().sort({ createdAt: -1 });
    res.json(gastos);
  } catch (err) {
    res.status(500).json({ msg: "Error listando gastos", error: err.message });
  }
};

export const crearGasto = async (req, res) => {
  try {
    const { nombre, depto, monto, estado } = req.body;
    const g = new Gasto({ nombre, depto, monto, estado });
    await g.save();
    res.status(201).json(g);
  } catch (err) {
    res.status(400).json({ msg: "Error creando gasto", error: err.message });
  }
};

export const eliminarGasto = async (req, res) => {
  try {
    const { id } = req.params;
    const eliminado = await Gasto.findByIdAndDelete(id);
    if (!eliminado) return res.status(404).json({ msg: "Gasto no encontrado" });
    res.json({ msg: "Gasto eliminado", id: eliminado._id });
  } catch (err) {
    res.status(500).json({ msg: "Error eliminando gasto", error: err.message });
  }
};

export const totalGastos = async (req, res) => {
  try {
    const result = await Gasto.aggregate([
      { $group: { _id: null, total: { $sum: "$monto" } } }
    ]);
    res.json({ total: result[0]?.total || 0 });
  } catch (err) {
    res.status(500).json({ msg: "Error calculando total", error: err.message });
  }
};