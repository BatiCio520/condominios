import Anuncio from "../models/anuncio.model.js";

export const crearAnuncio = async (req, res) => {
  try {
    const a = new Anuncio({ ...req.body, creador: req.user?.id });
    await a.save();
    res.status(201).json(a);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const listarAnuncios = async (req, res) => {
  try {
    const anuncios = await Anuncio.find({ activo: true }).sort({ fecha: -1 }).populate("creador", "nombre");
    res.json(anuncios);
  } catch (err) { res.status(500).json({ error: err.message }); }
};