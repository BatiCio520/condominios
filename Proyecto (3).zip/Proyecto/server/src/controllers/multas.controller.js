import Multa from "../models/multa.model.js";

export const crearMulta = async (req, res) => {
  try {
    const { residenteId, motivo, monto } = req.body;
    const m = new Multa({ residenteId, motivo, monto });
    await m.save();
    res.status(201).json(m);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const listarMultas = async (req, res) => {
  try {
    const q = req.query.residente || null;
    const filter = q ? { residenteId: q } : {};
    const multas = await Multa.find(filter).sort({ fecha: -1 }).populate("residenteId", "nombre email depto");
    res.json(multas);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const actualizarMulta = async (req, res) => {
  try {
    const m = await Multa.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!m) return res.status(404).json({ msg: "Multa no encontrada" });
    res.json(m);
  } catch (err) { res.status(500).json({ error: err.message }); }
};