import mongoose from "mongoose";
import dotenv from "dotenv";
import bcrypt from "bcrypt";
import connectDB from "../config/db.js";
import User from "../models/user.model.js";
dotenv.config();

const seed = async () => {
  await connectDB();
  const users = [
    { nombre: "Súper Admin", email: "admin@local", password: "admin123", role: "admin" },
    { nombre: "Conserje", email: "conserje@local", password: "conserje123", role: "conserje" },
    { nombre: "Directiva", email: "directiva@local", password: "directiva123", role: "directiva" },
    { nombre: "Residente", email: "residente@local", password: "residente123", role: "residente", depto: "A101" },
  ];
  for (const u of users) {
    const exists = await User.findOne({ email: u.email });
    if (!exists) {
      const hash = await bcrypt.hash(u.password, 10);
      await User.create({ nombre: u.nombre, email: u.email, password: hash, role: u.role, depto: u.depto });
      console.log("Creado:", u.email);
    } else console.log("Ya existe:", u.email);
  }
  process.exit(0);
};

seed().catch(e=>{ console.error(e); process.exit(1); });