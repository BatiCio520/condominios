import express from "express";
import { listarReservas, crearReserva, eliminarReserva } from "../controllers/reserva.controller.js";
import { authenticate, authorize } from "../middlewares/auth.js";

const router = express.Router();

router.get("/", authenticate, authorize("admin","conserje","directiva","residente"), listarReservas);
router.post("/", authenticate, authorize("admin","conserje","residente"), crearReserva);
router.delete("/:id", eliminarReserva);

export default router;