import express from "express";
import { listarGastos, crearGasto, eliminarGasto } from "../controllers/gastos.controller.js";
import { validarGasto } from "../middlewares/validar.js";
import { authenticate, authorize } from "../middlewares/auth.js";

const router = express.Router();

router.get("/", authenticate, authorize("admin","conserje","directiva"), listarGastos);
router.post("/", authenticate, authorize("admin","directiva"), validarGasto, crearGasto);
router.delete("/:id", authenticate, authorize("admin"), eliminarGasto);

export default router;