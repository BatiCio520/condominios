import express from "express";
import { listUsers, getUser, disableUser, createResident } from "../controllers/users.controller.js";
import { authenticate, authorize } from "../middlewares/auth.js";

const router = express.Router();

// Solo admin puede listar/deshabilitar; admin/directiva pueden ver usuarios; admin puede crear residentes
router.get("/", authenticate, authorize("admin"), listUsers);
router.get("/:id", authenticate, authorize("admin","directiva","conserje"), getUser);
router.post("/residente", authenticate, authorize("admin"), createResident);
router.patch("/:id/disable", authenticate, authorize("admin"), disableUser);

export default router;