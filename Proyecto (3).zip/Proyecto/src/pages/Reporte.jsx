import React from "react";

function Reporte() {
  return (
    <main>
      <h1>Reporte</h1>
      {/* contenido de reportes aquí */}
    </main>
  );
}

export default Reporte;