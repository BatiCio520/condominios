import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Gastos() {
  const [gastos, setGastos] = useState([]);
  const [form, setForm] = useState({ nombre: "", depto: "", monto: "", estado: "Pagado" });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const API = import.meta.env.VITE_API_URL || "http://localhost:5000";
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      navigate("/login");
      return;
    }
    fetchGastos();
  }, [token, navigate]);

  const fetchGastos = async () => {
    try {
      const res = await fetch(`${API}/api/gastos`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (Array.isArray(data)) {
        setGastos(data.map(g => ({ ...g, monto: String(g.monto) })));
      }
    } catch (err) {
      console.error("Error al cargar gastos:", err);
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/gastos`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ...form, monto: Number(form.monto) }),
      });
      if (res.ok) {
        setForm({ nombre: "", depto: "", monto: "", estado: "Pagado" });
        fetchGastos();
      }
    } catch (err) {
      console.error("Error:", err);
    }
    setLoading(false);
  };

  const handleDelete = async (id) => {
    if (window.confirm("¿Eliminar este gasto?")) {
      try {
        await fetch(`${API}/api/gastos/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchGastos();
      } catch (err) {
        console.error("Error:", err);
      }
    }
  };

  const total = gastos.reduce((acc, g) => acc + Number(g.monto || 0), 0);

  return (
    <div style={{ padding: "20px" }}>
      <h1>
        <img src="/IMAGENES/GASTOS.png" alt="Gastos" style={{height: "40px", marginRight: "10px"}} />
        Gestión de Gastos Comunes
      </h1>

      <div className="form-container">
        <h2>Crear Nuevo Gasto</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="nombre"
            placeholder="Nombre"
            value={form.nombre}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="depto"
            placeholder="Departamento"
            value={form.depto}
            onChange={handleChange}
            required
          />
          <input
            type="number"
            name="monto"
            placeholder="Monto"
            value={form.monto}
            onChange={handleChange}
            required
          />
          <select name="estado" value={form.estado} onChange={handleChange}>
            <option>Pagado</option>
            <option>Pendiente</option>
          </select>
          <button type="submit" disabled={loading}>
            {loading ? "Creando..." : "Crear Gasto"}
          </button>
        </form>
      </div>

      <div className="table-container">
        <h2>Gastos Registrados</h2>
        <p>
          <strong>Total: ${total.toLocaleString()}</strong>
        </p>
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Departamento</th>
              <th>Monto</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {gastos.length > 0 ? (
              gastos.map((g) => (
                <tr key={g._id}>
                  <td>{g.nombre}</td>
                  <td>{g.depto}</td>
                  <td>${Number(g.monto).toLocaleString()}</td>
                  <td>{g.estado}</td>
                  <td>
                    <button onClick={() => handleDelete(g._id)}>🗑️ Eliminar</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" style={{ textAlign: "center" }}>
                  No hay gastos registrados
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Gastos;