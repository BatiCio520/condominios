import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Home() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (!userData) {
      navigate("/login");
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  if (!user) return <p>Cargando...</p>;

  return (
    <main>
      <h1>Bienvenido, {user.nombre}</h1>
      <p>Rol: <strong>{user.role}</strong></p>
      <p>Email: {user.email}</p>

      <nav>
        <a href="/gastos">Gastos</a>
        <a href="/reserva">Reservas</a>
        <button onClick={handleLogout}>Cerrar Sesión</button>
      </nav>
    </main>
  );
}

export default Home;