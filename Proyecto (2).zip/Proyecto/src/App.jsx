import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Nav from "./components/Nav";
import Login from "./pages/login";
import Register from "./pages/register";
import Home from "./pages/home";
import Gastos from "./pages/gastos";
import Reserva from "./pages/reserva";
import "./STYLES/stylesS.css";

function App() {
  return (
    <Router>
      <Nav />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<Home />} />
        <Route path="/gastos" element={<Gastos />} />
        <Route path="/reserva" element={<Reserva />} />
      </Routes>
    </Router>
  );
}

export default App;