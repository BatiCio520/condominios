import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../STYLES/stylesS.css";

function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch(`${API}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.msg || data.error || "Login fallido");
        setLoading(false);
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));

      setLoading(false);
      navigate("/");
    } catch (err) {
      setError("Error de conexión con el servidor");
      setLoading(false);
    }
  };

  return (
    <main className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <img src="/IMAGENES/LOGO.jpg" alt="Logo" style={{ height: "60px" }} />
          <h1>Condominio</h1>
          <p className="subtitle">Sistema de Gestión</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">
              <span className="icon">📧</span> Email
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">
              <span className="icon">🔐</span> Contraseña
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Tu contraseña"
              required
            />
          </div>

          {error && (
            <div className="error-msg">
              <span className="error-icon">⚠️</span> {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? "Ingresando..." : "Iniciar Sesión"}
          </button>
        </form>

        <div className="auth-divider">o</div>

        <p className="auth-link">
          ¿No tienes cuenta?{" "}
          <a href="/register" className="link-accent">
            Registrarse aquí
          </a>
        </p>

        <div className="test-users">
          <h3>📋 Usuarios de Prueba:</h3>
          <ul>
            <li>
              <strong>Admin:</strong> <br />
              <code>admin@local</code> / <code>admin123</code>
            </li>
            <li>
              <strong>Conserje:</strong> <br />
              <code>conserje@local</code> / <code>conserje123</code>
            </li>
            <li>
              <strong>Directiva:</strong> <br />
              <code>directiva@local</code> / <code>directiva123</code>
            </li>
            <li>
              <strong>Residente:</strong> <br />
              <code>residente@local</code> / <code>residente123</code>
            </li>
          </ul>
        </div>
      </div>
    </main>
  );
}

export default Login;