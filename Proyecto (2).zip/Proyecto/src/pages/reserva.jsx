import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import gastosImg from "...public/IMAGENES/gastos.png"; 

function Reserva() {
  const [reservas, setReservas] = useState([]);
  const [form, setForm] = useState({ nombre: "", espacio: "", fecha: "", hora: "", costo: "" });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const API = import.meta.env.VITE_API_URL || "http://localhost:5000";
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      navigate("/login");
      return;
    }
    fetchReservas();
  }, [token, navigate]);

  const fetchReservas = async () => {
    try {
      const res = await fetch(`${API}/api/reservas`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (Array.isArray(data)) {
        setReservas(data.map(r => ({ ...r, costo: String(r.costo) })));
      }
    } catch (err) {
      console.error("Error:", err);
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/reservas`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ...form, costo: Number(form.costo) }),
      });
      if (res.ok) {
        setForm({ nombre: "", espacio: "", fecha: "", hora: "", costo: "" });
        fetchReservas();
      }
    } catch (err) {
      console.error("Error:", err);
    }
    setLoading(false);
  };

  const handleDelete = async (id) => {
    if (window.confirm("¿Eliminar esta reserva?")) {
      try {
        await fetch(`${API}/api/reservas/${id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        fetchReservas();
      } catch (err) {
        console.error("Error:", err);
      }
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>
        <img src="/IMAGENES/RESERVA.png" alt="Reservas" style={{height: "40px", marginRight: "10px"}} />
        Reservas de Áreas Comunes
      </h1>

      <div className="form-container">
        <h2>Crear Nueva Reserva</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="nombre"
            placeholder="Nombre del residente"
            value={form.nombre}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="espacio"
            placeholder="Espacio (Ej: Sala de Eventos)"
            value={form.espacio}
            onChange={handleChange}
            required
          />
          <input
            type="date"
            name="fecha"
            value={form.fecha}
            onChange={handleChange}
            required
          />
          <input
            type="time"
            name="hora"
            value={form.hora}
            onChange={handleChange}
            required
          />
          <input
            type="number"
            name="costo"
            placeholder="Costo"
            value={form.costo}
            onChange={handleChange}
            required
          />
          <button type="submit" disabled={loading}>
            {loading ? "Reservando..." : "Crear Reserva"}
          </button>
        </form>
      </div>

      <div className="table-container">
        <h2>Reservas Activas</h2>
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Espacio</th>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Costo</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {reservas.length > 0 ? (
              reservas.map((r) => (
                <tr key={r._id}>
                  <td>{r.nombre}</td>
                  <td>{r.espacio}</td>
                  <td>{r.fecha}</td>
                  <td>{r.hora}</td>
                  <td>${Number(r.costo).toLocaleString()}</td>
                  <td>
                    <button onClick={() => handleDelete(r._id)}>🗑️ Eliminar</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" style={{ textAlign: "center" }}>
                  No hay reservas
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <h1>
        <img src={gastosImg} alt="Gastos" style={{ height: "40px" }} /> Gestión de
        Gastos
      </h1>
      <section>
        <h2>Listado de Reservas</h2>
        <table border="1">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Espacio Reservado</th>
              <th>Fecha</th>
              <th>Hora</th>
              <th>Costo</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {reservas.length === 0 ? (
              <tr>
                <td colSpan="6">No hay reservas registradas.</td>
              </tr>
            ) : (
              reservas.map((r, i) => (
                <tr key={i}>
                  <td>{r.nombre}</td>
                  <td>{r.espacio}</td>
                  <td>{r.fecha}</td>
                  <td>{r.hora}</td>
                  <td>${r.costo}</td>
                  <td>{r.estado}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}

export default Reserva;