export const getUser = () => {
  try { return JSON.parse(localStorage.getItem("user") || "null"); } catch { return null; }
};
export const getToken = () => localStorage.getItem("token");
export const isRole = (r) => { const u = getUser(); return u && u.role === r; };