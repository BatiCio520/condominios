import React from "react";
import CardSection from "./components/Card";

function App() {
  return (
    <div className="App">
      <CardSection />
      <section className="tarjetas">
        <div className="card">
          <a className="historia" href="/src/Paginas/registro.html">
            <img className="card-img" src={registroImg} alt="Registro" />
            <h6>REGISTRO</h6>
          </a>
        </div>

        <div className="card">
          <a href="/src/Paginas/gastos.html">
            <img className="card-img" src={gastosImg} alt="Gastos" />
            <h6>GASTOS</h6>
          </a>
        </div>
      </section>
    </div>
  );
}

export default App;import registroImg from "../assets/registro.png";
import gastosImg from "../assets/gastos.png"; 