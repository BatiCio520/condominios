import React from "react";

function Header() {
  return (
    <header className="header">
      <div className="container">
        <nav className="navegacion">
          <img src="./IMAGENES/EDIFICIO.png" alt="condominio logo" className="logo" />
          <ul className="nav-menu">
            <li><a className="link" href="/">Inicio</a></li>
            <li><a className="link" href="/login">Login</a></li>
            <li><a className="link" href="/exit">Salir</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;