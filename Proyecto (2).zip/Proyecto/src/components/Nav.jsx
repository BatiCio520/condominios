import React from "react";
import { Link } from "react-router-dom";

function Nav() {
  const user = JSON.parse(localStorage.getItem("user") || "null");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
  };

  return (
    <nav className="navbar">
      <div className="nav-brand">
        <img src="/IMAGENES/LOGO.jpg" alt="Logo" className="logo-img" />
        Condominio
      </div>
      <ul className="nav-links">
        <li><Link to="/">Inicio</Link></li>
        {user && <li><Link to="/gastos">Gastos</Link></li>}
        {user && <li><Link to="/reserva">Reservas</Link></li>}
        {!user && <li><Link to="/login">Login</Link></li>}
        {user && <li><button onClick={handleLogout}>Salir</button></li>}
      </ul>
    </nav>
  );
}

export default Nav;