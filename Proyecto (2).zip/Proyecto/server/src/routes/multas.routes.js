import express from "express";
import { crearMulta, listarMultas, actualizarMulta } from "../controllers/multas.controller.js";
import { authenticate, authorize } from "../middlewares/auth.js";

const router = express.Router();

router.get("/", authenticate, authorize("admin","conserje","directiva"), listarMultas);
router.post("/", authenticate, authorize("admin","directiva"), crearMulta);
router.patch("/:id", authenticate, authorize("admin","directiva"), actualizarMulta);

export default router;