import express from "express";
import { crearAnuncio, listarAnuncios } from "../controllers/anuncios.controller.js";
import { authenticate, authorize } from "../middlewares/auth.js";

const router = express.Router();

router.get("/", authenticate, listarAnuncios);
router.post("/", authenticate, authorize("admin","directiva"), crearAnuncio);

export default router;