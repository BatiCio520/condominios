import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import connectDB from "./config/db.js";
import gastosRoutes from "./routes/gastos.routes.js";
import reservaRoutes from "./routes/reserva.routes.js";
import authRoutes from "./routes/auth.routes.js";
import usersRoutes from "./routes/users.routes.js";
import multasRoutes from "./routes/multas.routes.js";
import anunciosRoutes from "./routes/anuncios.routes.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// API routes
app.use("/api/gastos", gastosRoutes);
app.use("/api/reservas", reservaRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", usersRoutes);
app.use("/api/multas", multasRoutes);
app.use("/api/anuncios", anunciosRoutes);

// Serve frontend build in production (optional)
if (process.env.NODE_ENV === "production") {
  const __dirname = path.resolve();
  app.use(express.static(path.join(__dirname, "../dist")));
  app.get("*", (req, res) => res.sendFile(path.join(__dirname, "../dist/index.html")));
}

const PORT = process.env.PORT || 5000;
connectDB()
  .then(() => {
    app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error("Failed to start server:", err);
    process.exit(1);
  });