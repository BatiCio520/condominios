import mongoose from "mongoose";

const GastoSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  depto: { type: String, required: true },
  monto: { type: Number, required: true },
  estado: { type: String, enum: ["Pagado", "Pendiente"], default: "Pagado" },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("Gasto", GastoSchema);