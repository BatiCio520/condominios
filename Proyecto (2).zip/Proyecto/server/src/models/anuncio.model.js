import mongoose from "mongoose";

const AnuncioSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  descripcion: { type: String },
  creador: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  fecha: { type: Date, default: Date.now },
  activo: { type: Boolean, default: true },
});

export default mongoose.model("Anuncio", AnuncioSchema);