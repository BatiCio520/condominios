import Reserva from "../models/reserva.model.js";

export const listarReservas = async (req, res) => {
  try {
    const reservas = await Reserva.find().sort({ createdAt: -1 });
    res.json(reservas);
  } catch (err) {
    res.status(500).json({ msg: "Error listando reservas", error: err.message });
  }
};

export const crearReserva = async (req, res) => {
  try {
    const { nombre, espacio, fecha, hora, costo } = req.body;
    const r = new Reserva({ nombre, espacio, fecha, hora, costo });
    await r.save();
    res.status(201).json(r);
  } catch (err) {
    res.status(400).json({ msg: "Error creando reserva", error: err.message });
  }
};

export const eliminarReserva = async (req, res) => {
  try {
    const { id } = req.params;
    const eliminado = await Reserva.findByIdAndDelete(id);
    if (!eliminado) return res.status(404).json({ msg: "Reserva no encontrada" });
    res.json({ msg: "Reserva eliminada", id: eliminado._id });
  } catch (err) {
    res.status(500).json({ msg: "Error eliminando reserva", error: err.message });
  }
};

// agrega endpoint para marcar pago y listar por residente
export const marcarPagoReserva = async (req, res) => {
  try {
    const { id } = req.params;
    const r = await Reserva.findByIdAndUpdate(id, { estado: "Finalizado" }, { new: true });
    if (!r) return res.status(404).json({ msg: "Reserva no encontrada" });
    res.json(r);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const listarReservasPorResidente = async (req, res) => {
  try {
    const { residenteId } = req.query;
    const q = residenteId ? { _id: residenteId } : {};
    // si se requiere, filtrar por usuario autenticado (si role residente)
    const reservas = await Reserva.find(q).sort({ createdAt: -1 });
    res.json(reservas);
  } catch (err) { res.status(500).json({ error: err.message }); }
};