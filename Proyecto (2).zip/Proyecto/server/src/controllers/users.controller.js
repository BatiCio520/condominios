import User from "../models/user.model.js";
import bcrypt from "bcrypt";

export const listUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password").sort({ createdAt: -1 });
    res.json(users);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password");
    if (!user) return res.status(404).json({ msg: "Usuario no encontrado" });
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const disableUser = async (req, res) => {
  try {
    const u = await User.findByIdAndUpdate(req.params.id, { active: false }, { new: true }).select("-password");
    if (!u) return res.status(404).json({ msg: "Usuario no encontrado" });
    res.json({ msg: "Usuario deshabilitado", user: u });
  } catch (err) { res.status(500).json({ error: err.message }); }
};

export const createResident = async (req, res) => {
  try {
    const { nombre, email, password, depto } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ msg: "Email ya registrado" });
    const hash = await bcrypt.hash(password || "changeme123", 10);
    const user = new User({ nombre, email, password: hash, role: "residente", depto });
    await user.save();
    res.status(201).json({ msg: "Residente creado", user: { id: user._id, nombre: user.nombre, email: user.email, role: user.role } });
  } catch (err) { res.status(500).json({ error: err.message }); }
};