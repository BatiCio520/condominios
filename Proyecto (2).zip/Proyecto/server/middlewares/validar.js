export const validarGasto = (req, res, next) => {
  const { nombre, depto, monto } = req.body;
  if (!nombre || !depto || monto == null) {
    return res.status(400).json({ msg: "Faltan campos requeridos: nombre, depto o monto" });
  }
  next();
};